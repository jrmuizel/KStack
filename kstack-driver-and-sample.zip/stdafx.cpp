/*
        KStack Sample Application - stdafx.cpp
		Copyright (C) 2009 aw.comyr.com
		Distributed under the ZLib license
		http://www.opensource.org/licenses/zlib-license.html
*/
#include "stdafx.h"
